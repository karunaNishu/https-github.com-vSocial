
<!doctype html> 
	
<html lang="en"> 

<head> 
<title>Register-vSocial</title>
<link rel="icon" type="image/x-icon" href="favicon.ico">	
	<!-- Required meta tags --> 
	<meta charset="utf-8"> 
	<meta name="viewport" content= 
		"width=device-width, initial-scale=1, 
		shrink-to-fit=no"> 
	
</head> 
	<script>
function home() {
  location.replace("http://localhost:81/Vsocial/Home.php")
}
function login() {
  location.replace("http://localhost:81/Vsocial/Login.php")
}
function blogger() {
  location.replace("http://localhost:81/Vsocial/bloggerLogin.php")
}
</script>
	
<body style="background-image: url(http://localhost:81/VSocial/dash.jpg); background-position: center"> 

<div style="text-align:right;">
<button onclick="home()">Home Page</button>  <button onclick="login()">User Login</button>   <button onclick="blogger()">Blogger Login</button><br/><br/>
	<h3>Register Below</h3>
	<form action="Register.php" method="post"> 
		<div>
			Username         <input type="test" name="username" id="username" maxlength=20/><br/><br/>
			Password         <input type="password" name="password" id="password" maxlength=20/></br><br/>
			Confirm Password <input type="password" name="cpassword" id="cpassword" maxlength=20/></br><br/>
			                 <input type="submit" id="register" value="Register"/>
		</div> 	 
	</form> 
</div> 
	
</body> 
</html> 

<?php 
	
$showAlert = false; 
$showError = false; 
$exists=false; 
$logdescription = "";
	
if($_SERVER["REQUEST_METHOD"] == "POST") { 
	 
	include 'dbconnect.php'; 
	
	$username = $_POST["username"]; 
	$password = $_POST["password"]; 
	$cpassword = $_POST["cpassword"]; 
				
	$sql = "Select * from users where username='$username'"; 
	
	$result = mysqli_query($conn, $sql); 
	
	$num = mysqli_num_rows($result); 
		
	if($num == 0) {
		if($username == "" || $password == ""){
			$showError = "Username or Password cannot be blank!";
		}			
		else{
			if(($password == $cpassword) && $exists==false) { 
									 
				$sql = "INSERT INTO `users` ( `username`, 
					`password`) VALUES ('$username', 
					'$password')"; 
		
				$result = mysqli_query($conn, $sql); 
				
				$sqlc = "SELECT * FROM users";
				$result2 = mysqli_query($conn, $sqlc); 				
				$ucount = mysqli_num_rows($result2);
				
				$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
				$timestamp = date('m/d/Y h:i:s a', time());
				$logdescription = "User registered with Username:".htmlentities($username)."<br/>UserAgent:".$_SERVER['HTTP_USER_AGENT'];
				$logsql = "INSERT INTO `logs` ( `url`,`timestamp`,`description`) VALUES ('$url','$timestamp','$logdescription')";
				$logresult = mysqli_query($conn, $logsql);
				
				
				$xml = new DOMDocument('1.0', 'utf-8');
				$xml->formatOutput = true; 
				$xml->preserveWhiteSpace = false;
				$xml->load('usercount.xml');

				$element = $xml->getElementsByTagName('counts')->item(0);  

				$usercount = $element->getElementsByTagName('users')->item(0);

				$usercount->nodeValue = $ucount;
				htmlentities($xml->save('usercount.xml'));
				
		
				if ($result) { 
					$showAlert = true; 
				} 
			} 
			else { 
				$showError = "Passwords do not match"; 
			}
		}		
	}// end if 
	
if($num>0) 
{ 
	$exists="Username not available"; 
} 
	
}//end if 
	
?>

<?php 
	
	if($showAlert) { 
	
		echo ' <div style="text-align:right;" class="alert alert-success 
			alert-dismissible fade show" role="alert"> 
	
			<strong>Success!</strong> Your account is 
			now created and you can login. 
			<button type="button" class="close"
				data-dismiss="alert" aria-label="Close"> 
				<span aria-hidden="true">�</span> 
			</button> 
		</div> '; 
	} 
	
	if($showError) { 
	
		echo ' <div style="text-align:right;" class="alert alert-danger 
			alert-dismissible fade show" role="alert"> 
		<strong>Error!</strong> '. $showError.'
	
	<button type="button" class="close"
			data-dismiss="alert aria-label="Close"> 
			<span aria-hidden="true">�</span> 
	</button> 
	</div> '; 
} 
		
	if($exists) { 
		echo ' <div style="text-align:right;" class="alert alert-danger 
			alert-dismissible fade show" role="alert"> 
	
		<strong>Error!</strong> '. $exists.'
		<button type="button" class="close"
			data-dismiss="alert" aria-label="Close"> 
			<span aria-hidden="true">�</span> 
		</button> 
	</div> '; 
	} 

?> 